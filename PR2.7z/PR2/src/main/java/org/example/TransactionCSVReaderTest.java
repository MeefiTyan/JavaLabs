package org.example;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

class TransactionCSVReaderTest {
    private List<Transaction> readTransactionsFromString(String csvData) {
        List<Transaction> transactions = new ArrayList<>();
        String[] lines = csvData.split("\n");
        for (String line : lines) {
            String[] values = line.split(",");
            Transaction transaction = new Transaction(values[0], Double.parseDouble(values[1]), values[2]);
            transactions.add(transaction);
        }
        return transactions;
    }

    @Test
    public void testReadTransactions() {
        String testCsvData = "01-01-2023,100.0,Income\n" +
                "02-01-2023,50.5,Expense\n" +
                "03-01-2023,75.0,Income";

        List<Transaction> transactions = readTransactionsFromString(testCsvData);

        Assertions.assertNotNull(transactions, "Список транзакцій не повинен бути null");
        Assertions.assertTrue(transactions.size() > 0, "Список транзакцій не повинен бути порожнім");

        Transaction firstTransaction = transactions.get(0);
        Assertions.assertEquals("01-01-2023", firstTransaction.getDate(), "Неправильна дата");
        Assertions.assertEquals(100.0, firstTransaction.getAmount(), "Неправильна сума");
        Assertions.assertEquals("Income", firstTransaction.getDescription(), "Неправильний опис");
    }
}

