package org.example;
import java.util.List;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;


public abstract class TransactionReportGenerator {

    public static void printBalanceReport(double totalBalance) {
        System.out.println("Загальний баланс: " + totalBalance);
    }

    public static void printTransactionsCountByMonth(String monthYear, int count) {
        System.out.println("Кількість транзакцій за " + monthYear + ": " + count);
    }
    public static void printTopExpensesReport(List<Transaction> topExpenses) {
        System.out.println("10 найбільших витрат:");
        for (Transaction expense : topExpenses) {
            System.out.println(expense.getDescription() + ": " + expense.getAmount());
        }
    }

    public static void printCategoryExpenseReport(List<Transaction> transactions) {
        Map<String, Double> categoryExpenses = new HashMap<>();

        for (Transaction transaction : transactions) {
            if (transaction.getAmount() < 0) {
                categoryExpenses.put(transaction.getDescription(), categoryExpenses.getOrDefault(transaction.getDescription(), 0.0) + transaction.getAmount());
            }
        }

        for (Map.Entry<String, Double> entry : categoryExpenses.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
            int symbols = (int) Math.abs(entry.getValue() / 1000);
            System.out.println("*".repeat(symbols));
        }
    }

    public static void printMonthlyExpenseReport(List<Transaction> transactions) {
        Map<String, Double> monthlyExpenses = new HashMap<>();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-yyyy");

        for (Transaction transaction : transactions) {
            if (transaction.getAmount() < 0) {
                LocalDate date = LocalDate.parse(transaction.getDate(), DateTimeFormatter.ofPattern("dd-MM-yyyy"));
                String monthYear = date.format(formatter);
                monthlyExpenses.put(monthYear, monthlyExpenses.getOrDefault(monthYear, 0.0) + transaction.getAmount());
            }
        }

        for (Map.Entry<String, Double> entry : monthlyExpenses.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
            int symbols = (int) Math.abs(entry.getValue() / 1000); // 1 символ на кожну 1000 грн
            System.out.println("*".repeat(symbols));
        }
    }

}
